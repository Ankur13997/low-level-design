#include "Splitwise.cpp"
int main()
{
    Splitwise splitwise;
    splitwise.demo();
    return 0;
}