#pragma once
enum SplitType
{
    EQUAL,
    PERCENTAGE,
    EXACT
};