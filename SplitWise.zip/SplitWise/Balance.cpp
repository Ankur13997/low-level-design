#pragma once
#include<iostream>
#include<bits/stdc++.h>
using namespace std;
class Balance
{
public:
    /* data */
    double owed=0;
    double recieve=0;
    
};
